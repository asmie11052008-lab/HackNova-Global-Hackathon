# VoiceCare TN (Team VSB) - website

The whole app is one file: index.html. No install, no server, no build step.

## Get your own link (about 2 minutes, free)

### Option A: Netlify Drop (easiest)
1. Unzip this file.
2. Open https://app.netlify.com/drop and drag the unzipped folder onto the page.
3. Sign in (free) so the site stays online, then copy your link (https://something.netlify.app).
4. Optional: Site settings > Change site name, e.g. voicecare-tn.

### Option B: GitHub Pages
1. Create a new public repository, e.g. voicecare-tn.
2. Upload index.html to it.
3. Settings > Pages > Deploy from a branch > main > / (root) > Save.
4. Your link will be https://YOUR-USERNAME.github.io/voicecare-tn/

## Before you submit
- Hospital records are SAMPLE data. Add real ones in Staff login (PIN 1234, change it inside index.html).
- Call-back requests and the SMS log are stored in the visitor's own browser.
- Call, Directions and SMS buttons work best on a phone.
